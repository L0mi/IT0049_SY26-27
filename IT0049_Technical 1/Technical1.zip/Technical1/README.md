# Tindahan POS

Tindahan POS is a four-page CodeIgniter 4 project for IT0049 Technical Formative Assessment 1. It demonstrates explicit routing, controllers, models, reusable views, validated registration forms, and persistent MariaDB storage.

## Pages

- `/` - landing page and project dashboard
- `/about` - overview of the MVC request flow
- `/customers` - customer records with full name, email, and phone
- `/users` - staff records with username, full name, and role

The customer and user directories are loaded through CodeIgniter models and rendered with `foreach` loops in the views. Both pages include validated registration forms. Newly registered records are saved permanently in the `technical1_pos` database.

## Requirements

- PHP 8.2 or newer
- XAMPP with Apache enabled
- PHP extensions required by CodeIgniter, including `intl` and `mbstring`
- XAMPP MySQL or MariaDB running on port 3306

## Database setup

The included `.env` file connects to a local database named `technical1_pos` using XAMPP's default development credentials (`root` with no password).

Create the database, run the schema migrations, and add the sample records:

```bash
/Applications/XAMPP/xamppfiles/bin/mysql -u root -e "CREATE DATABASE IF NOT EXISTS technical1_pos CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
php spark migrate
php spark db:seed PosSeeder
```

The database contains:

- `customers` - full name, unique email address, phone number, and timestamps
- `users` - unique username, full name, authorized role, and timestamps

Open `http://localhost/phpmyadmin/` when XAMPP Apache is running to browse or export the database.

## Run the application

The project is already located inside XAMPP's `htdocs` directory. From the `Technical1` directory, run:

```console
php spark serve
```

Then open `http://localhost:8080/`. The included `.env` file is configured for this address.

If you prefer to use XAMPP's Apache server, make sure XAMPP PHP has the required `intl` and `mbstring` extensions enabled. Then change `app.baseURL` in `.env` to `http://localhost/Technical1/public/`, start Apache, and open that address.

## Project structure

```text
app/Config/Routes.php          Route definitions for all four pages
app/Controllers/Pages.php      Landing and About page controller
app/Controllers/Customers.php Customer registration and directory logic
app/Controllers/Users.php     User registration and directory logic
app/Models/                    Customer and user database models
app/Database/Migrations/      Reproducible database schema
app/Database/Seeds/           Initial sample records
app/Views/layouts/             Shared header, navigation, and footer
app/Views/pages/               Four page views
public/assets/css/style.css    Responsive interface styles
database/technical1_pos.sql   Ready-to-import database export
```

To export the database for submission, use phpMyAdmin's Export tab or run:

```bash
/Applications/XAMPP/xamppfiles/bin/mysqldump -u root technical1_pos > technical1_pos.sql
```
