<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PosSeeder extends Seeder
{
    public function run()
    {
        if ($this->db->table('customers')->countAllResults() === 0) {
            $this->db->table('customers')->insertBatch([
                ['full_name' => 'Andrea Santos', 'email' => 'andrea.santos@example.com', 'phone' => '0917 482 1103'],
                ['full_name' => 'Miguel Reyes', 'email' => 'miguel.reyes@example.com', 'phone' => '0918 735 2246'],
                ['full_name' => 'Sofia Lim', 'email' => 'sofia.lim@example.com', 'phone' => '0920 614 3891'],
                ['full_name' => 'Paolo Garcia', 'email' => 'paolo.garcia@example.com', 'phone' => '0921 847 5062'],
                ['full_name' => 'Camille Dela Cruz', 'email' => 'camille.delacruz@example.com', 'phone' => '0927 330 7485'],
                ['full_name' => 'Noah Mendoza', 'email' => 'noah.mendoza@example.com', 'phone' => '0935 912 6614'],
            ]);
        }

        if ($this->db->table('users')->countAllResults() === 0) {
            $this->db->table('users')->insertBatch([
                ['username' => 'admin.mara', 'full_name' => 'Mara Villanueva', 'role' => 'Administrator'],
                ['username' => 'cashier.jules', 'full_name' => 'Jules Navarro', 'role' => 'Cashier'],
                ['username' => 'cashier.ren', 'full_name' => 'Ren Castillo', 'role' => 'Cashier'],
                ['username' => 'inventory.ana', 'full_name' => 'Ana Flores', 'role' => 'Inventory Staff'],
                ['username' => 'manager.eli', 'full_name' => 'Elijah Ramos', 'role' => 'Store Manager'],
                ['username' => 'support.kim', 'full_name' => 'Kim Bautista', 'role' => 'Support Staff'],
            ]);
        }
    }
}
