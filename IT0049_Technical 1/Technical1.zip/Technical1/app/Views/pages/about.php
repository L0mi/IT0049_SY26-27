<?= $this->include('layouts/header') ?>

<section class="page-intro">
    <p class="eyebrow">About the project</p>
    <h1>A practical first step into CodeIgniter MVC.</h1>
    <p>This four-page POS foundation turns incoming URLs into useful interfaces through explicit routes, focused controllers, and reusable views.</p>
</section>

<section class="about-grid">
    <article class="content-card large-card">
        <p class="eyebrow">How it works</p>
        <h2>From request to rendered page</h2>
        <ol class="process-list">
            <li><span>1</span><div><strong>A route receives the URL.</strong><p>The route table maps each address to the correct controller method.</p></div></li>
            <li><span>2</span><div><strong>A controller prepares the page.</strong><p>Controllers select a view and provide any data that the page needs.</p></div></li>
            <li><span>3</span><div><strong>A view renders the interface.</strong><p>PHP templates produce the HTML that visitors see in their browser.</p></div></li>
        </ol>
    </article>

    <aside class="content-card details-card">
        <p class="eyebrow">Current scope</p>
        <h2>Foundation release</h2>
        <dl>
            <div><dt>Framework</dt><dd>CodeIgniter 4</dd></div>
            <div><dt>Architecture</dt><dd>Model View Controller</dd></div>
            <div><dt>Data source</dt><dd>CodeIgniter models</dd></div>
            <div><dt>Database</dt><dd>MariaDB and MySQL</dd></div>
        </dl>
    </aside>
</section>

<?= $this->include('layouts/footer') ?>
