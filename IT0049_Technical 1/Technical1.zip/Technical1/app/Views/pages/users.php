<?= $this->include('layouts/header') ?>

<section class="page-intro compact-intro">
    <div>
        <p class="eyebrow">Team directory</p>
        <h1>User Accounts</h1>
        <p>Staff identities and access roles stored permanently in the point-of-sale database.</p>
    </div>
    <span class="count-badge"><?= count($users) ?> records</span>
</section>

<?php if ($success): ?>
    <div class="alert alert-success" role="status">
        <strong>User authorized.</strong>
        <span><?= esc($success) ?></span>
    </div>
<?php endif ?>

<section class="registration-card" id="register-user">
    <div class="registration-copy">
        <p class="eyebrow">New staff account</p>
        <h2>Register an authorized user</h2>
        <p>Create a permanent staff record and assign one of the approved store roles. The new user will appear in the directory below.</p>
    </div>

    <form action="<?= site_url('users') ?>" method="post" class="registration-form">
        <?= csrf_field() ?>
        <div class="form-grid">
            <div class="form-field">
                <label for="staff-username">Username</label>
                <input id="staff-username" name="username" type="text" value="<?= esc(old('username')) ?>" autocomplete="username" maxlength="30" placeholder="e.g. cashier.sam" required aria-describedby="staff-username-error">
                <?php if (isset($errors['username'])): ?><small class="field-error" id="staff-username-error"><?= esc($errors['username']) ?></small><?php endif ?>
            </div>
            <div class="form-field">
                <label for="staff-name">Full name</label>
                <input id="staff-name" name="fullName" type="text" value="<?= esc(old('fullName')) ?>" autocomplete="name" maxlength="80" required aria-describedby="staff-name-error">
                <?php if (isset($errors['fullName'])): ?><small class="field-error" id="staff-name-error"><?= esc($errors['fullName']) ?></small><?php endif ?>
            </div>
            <div class="form-field">
                <label for="staff-role">Authorized role</label>
                <select id="staff-role" name="role" required aria-describedby="staff-role-error">
                    <option value="">Choose a role</option>
                    <?php foreach (['Administrator', 'Store Manager', 'Cashier', 'Inventory Staff', 'Support Staff'] as $role): ?>
                        <option value="<?= esc($role) ?>" <?= old('role') === $role ? 'selected' : '' ?>><?= esc($role) ?></option>
                    <?php endforeach ?>
                </select>
                <?php if (isset($errors['role'])): ?><small class="field-error" id="staff-role-error"><?= esc($errors['role']) ?></small><?php endif ?>
            </div>
            <div class="form-submit">
                <button type="submit">Authorize user</button>
                <small>Saved permanently to MySQL</small>
            </div>
        </div>
    </form>
</section>

<section class="table-card">
    <div class="table-title">
        <div>
            <h2>Authorized users</h2>
            <p>Usernames, names, and store responsibilities</p>
        </div>
        <span class="status"><span></span> MySQL database</span>
    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th scope="col">Username</th>
                    <th scope="col">Full name</th>
                    <th scope="col">Role</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td data-label="Username"><code><?= esc($user['username']) ?></code></td>
                        <td data-label="Full name"><strong><?= esc($user['fullName']) ?></strong></td>
                        <td data-label="Role"><span class="role-badge"><?= esc($user['role']) ?></span></td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </div>
</section>

<?= $this->include('layouts/footer') ?>
