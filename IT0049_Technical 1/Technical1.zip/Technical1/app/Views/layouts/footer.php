    </main>

    <footer class="site-footer">
        <div class="footer-shell">
            <p><strong>Tindahan POS</strong> &middot; CodeIgniter 4 Foundations</p>
            <p>IT0049 Technical Formative Assessment 1</p>
        </div>
    </footer>
</body>
</html>
