<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    public function index(): string
    {
        $model = new UserModel();
        $users = array_map(
            static fn (array $user): array => [
                'username' => $user['username'],
                'fullName' => $user['full_name'],
                'role' => $user['role'],
            ],
            $model->orderBy('id', 'ASC')->findAll()
        );

        return view('pages/users', [
            'title' => 'User Accounts',
            'activePage' => 'users',
            'users' => $users,
            'errors' => session()->getFlashdata('errors') ?? [],
            'success' => session()->getFlashdata('success'),
        ]);
    }

    public function create()
    {
        $data = [
            'username' => strtolower(trim((string) $this->request->getPost('username'))),
            'fullName' => trim((string) $this->request->getPost('fullName')),
            'role' => trim((string) $this->request->getPost('role')),
        ];

        $rules = [
            'username' => 'required|regex_match[/^[a-z0-9._-]+$/]|min_length[4]|max_length[30]',
            'fullName' => 'required|min_length[2]|max_length[80]',
            'role' => 'required|in_list[Administrator,Store Manager,Cashier,Inventory Staff,Support Staff]',
        ];

        $messages = [
            'username' => [
                'required' => 'Please enter a username.',
                'regex_match' => 'The username may contain only lowercase letters, numbers, dots, underscores, and dashes.',
                'min_length' => 'The username must contain at least 4 characters.',
            ],
            'fullName' => [
                'required' => 'Please enter the staff member\'s full name.',
                'min_length' => 'The full name must contain at least 2 characters.',
            ],
            'role' => [
                'required' => 'Please choose an authorized role.',
                'in_list' => 'Please choose one of the available authorized roles.',
            ],
        ];

        if (! $this->validateData($data, $rules, $messages)) {
            return redirect()->to(site_url('users') . '#register-user')
                ->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $model = new UserModel();
        if ($model->where('username', $data['username'])->first() !== null) {
            return redirect()->to(site_url('users') . '#register-user')
                ->withInput()
                ->with('errors', ['username' => 'That username is already registered.']);
        }

        $model->insert([
            'username' => $data['username'],
            'full_name' => $data['fullName'],
            'role' => $data['role'],
        ]);

        return redirect()->to(site_url('users'))
            ->with('success', $data['fullName'] . ' was registered as an authorized user.');
    }
}
